// DlgAsynloginWait.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ClientDemo.h"
#include "DlgAsynloginWait.h"
#include "afxdialogex.h"


// CDlgAsynloginWait �Ի���

IMPLEMENT_DYNAMIC(CDlgAsynloginWait, CDialog)

CDlgAsynloginWait::CDlgAsynloginWait(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgAsynloginWait::IDD, pParent)
{

}

CDlgAsynloginWait::~CDlgAsynloginWait()
{
}

void CDlgAsynloginWait::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgAsynloginWait, CDialog)
END_MESSAGE_MAP()


// CDlgAsynloginWait ��Ϣ��������
